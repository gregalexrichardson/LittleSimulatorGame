﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sim1
{
    public partial class Form1 : Form
    {

        public List<Building> buildings;

        List<Person> people;
        public Form1()
        {
            InitializeComponent();
            people = new List<Person>();


            buildings = new List<Building>();
            buildings.Add(new BurgerShop(new Vector2D(5, 5)));
            buildings.Add(new BurgerShop(new Vector2D(20, 25)));
            buildings.Add(new SpinnerShop(new Vector2D(15, 15)));


            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            dgvPeople.Rows.Clear();
            foreach(Person person in people)
            {
                dgvPeople.Rows.Add(person.Name, person.Happiness, person.Money, person.Satiation, person.sc.stateName, "(" + person.Position.x.ToString() + ", " + person.Position.y.ToString() + ")", "(" + person.Destination.x.ToString() + ", " + person.Destination.y.ToString() + ")", person._gameItem != null ? person._gameItem._name : "", person._gameItem != null ? person._gameItem._uses : 0);
            }
        }

        private void addPerson_Click(object sender, EventArgs e)
        {
            people.Add(new Person(timer1, this));
        }

        private void dgvPeople_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
