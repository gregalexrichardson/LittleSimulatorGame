﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sim1
{
    public class Building
    {
        public string _name;
        public string _type;
        public Vector2D _position;
        public virtual void OnEnter() { }
        public virtual void OnExit() { }
        public virtual void UpdateState() { }
        public virtual void Use(Person person) { }
        public Building(Vector2D position) {
            _position = position; 
        }
    }

    public class Shop : Building
    {
        public GameItem _gameItem; //this would actually be an object that can be acquired by the person
        public float _price;
        public Shop(Vector2D position) : base(position) {}
        public override void Use(Person person)
        {
            base.Use(person);
            if (person.Money >= _price)
            {
                person.Receive((GameItem)_gameItem.Clone(person));
                person.Money -= _price;
            }
        }
    }

    public class BurgerShop : Shop
    {
        public BurgerShop(Vector2D position) : base(position)
        {
            _name = "Burger Shop";
            _type = "Food";
            _price = 2.50f;
            _gameItem = new Burger();
        }
    }

    public class SpinnerShop : Shop
    {
        public SpinnerShop(Vector2D position) : base(position)
        {
            _name = "Spinner Shop";
            _type = "Entertainment";
            _price = 5.0f ;
            _gameItem = new FidgetSpinner();
        }
    }
}
