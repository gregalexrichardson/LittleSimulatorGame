﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sim1
{
    public class Vector2D
    {
        public float x;
        public float y;
        public Vector2D(float _x, float _y)
        {
            x = _x;
            y = _y;
        }

        public float Distance(Vector2D other)
        {
            return (float)Math.Sqrt(Math.Pow(other.x - x, 2) + Math.Pow(other.y - y, 2));
        }
        
        public Vector2D UnitTowards(Vector2D other, float size = 1.0f)
        {
            float mag = size / Distance(other);
            return new Vector2D(mag * (other.x - x), mag * (other.y - y));
        }

        public void MoveTowards(Vector2D other, float steps = 1.0f)
        {
            Vector2D unitTowards = UnitTowards(other);
            x += steps * unitTowards.x;
            y += steps * unitTowards.y;
        }
    }

    public class Person
    {
        public string Name;
        public float Happiness = 100f;
        public float Money = 100f;
        public float Satiation = 100f;
        public PersonStateController sc;
        public Vector2D Position = new Vector2D(10,10);
        public Vector2D Destination = new Vector2D(10, 10);
        public Building DestBuilding;
        Vector2D Direction;
        public int steps = 0;
        public GameItem _gameItem;
        public Form1 parent;

        public Person(Timer t1, Form1 form)
        {
            parent = form;
            Name = RandomString(5);
            sc = new PersonStateController(this);

            t1.Tick += Update;
        }

        private void Update(object sender, EventArgs e)
        {
            sc.Update();

            if(Position != Destination)
            {
                Direction = Position.UnitTowards(Destination);

                if (Position.Distance(Destination) > 1)
                {
                    Position.MoveTowards(Destination, 1.0f);
                }
            }

            if(_gameItem != null)
            {
                _gameItem.Use();

                //fix this:
                if (_gameItem._uses <= 0)
                {
                    _gameItem = null;
                }
            }
        }

        private static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public void MoveTo(Vector2D newPos)
        {
            DestBuilding = null;
            Destination = newPos;
        }
        public void MoveTo(Building newPos)
        {
            DestBuilding = newPos;
            Destination = newPos._position;
        }

        public void Receive(GameItem gameItem)
        {
            if(_gameItem != null)
                _gameItem.Dispose();
            _gameItem = gameItem;
        }

    }

    public class PersonStateController
    {
        public PersonState _personState;
        public Person _person;

        public WalkingState walkingState;
        public HungryState hungryState;
        public SadState sadState;

        public string stateName;


        public PersonStateController(Person person)
        {
            _person = person;

            walkingState = new WalkingState(_person, this);
            hungryState = new HungryState(_person, this);
            sadState = new SadState(_person, this);

            _personState = walkingState;
            stateName = _personState._name;
        }

        public void Update()
        {
            _personState.UpdateState();
        }

        public void ChangeState(PersonState newState)
        {
            _personState.OnExit();
            _personState = newState;
            stateName = _personState._name;
            _personState.OnEnter();
        }

    }

    public class PersonState
    {
        public Person _person;
        public PersonStateController _sc;
        public string _name;
        public virtual void OnEnter() { }
        public virtual void OnExit() { }
        public virtual void UpdateState() { }
        public PersonState(Person person, PersonStateController sc)
        {
            _person = person;
            _sc = sc;
        }
    }

    public class HungryState : PersonState
    {
        public HungryState(Person person, PersonStateController sc) : base(person, sc)
        {
            _name = "Hungry";
        }
        public override void OnEnter()
        {
            base.OnEnter();
            Building buildingClosest = (from buildings in _person.parent.buildings where buildings._type == "Food" orderby _person.Position.Distance(buildings._position) ascending select buildings).FirstOrDefault();
            _person.MoveTo(buildingClosest);
        }
        public override void UpdateState()
        {
            base.UpdateState();
            _person.Satiation--;
            _person.Happiness-=2;
            if(_person.Position.Distance(_person.Destination) < 1)
            {
                if (_person.DestBuilding != null)
                    _person.DestBuilding.Use(_person);
                //_person.MoveTo(new Vector2D(10,10));
                _sc.ChangeState(_sc.walkingState);
            }
        }
    }

    public class SadState : PersonState
    {
        public SadState(Person person, PersonStateController sc) : base(person, sc)
        {
            _name = "Sad";
        }
        public override void OnEnter()
        {
            base.OnEnter();
            Building buildingClosest = (from buildings in _person.parent.buildings where buildings._type == "Entertainment" orderby _person.Position.Distance(buildings._position) ascending select buildings).FirstOrDefault();
            _person.MoveTo(buildingClosest);
        }
        public override void UpdateState()
        {
            base.UpdateState();
            _person.Satiation--;
            _person.Happiness--;
            if (_person.Position.Distance(_person.Destination) < 1)
            {
                if(_person.DestBuilding != null)
                    _person.DestBuilding.Use(_person);
                //_person.MoveTo(new Vector2D(10,10));
                _sc.ChangeState(_sc.walkingState);
            }
        }
    }

    public class WalkingState : PersonState
    {
        public WalkingState(Person person, PersonStateController sc) : base(person, sc)
        {
            _name = "Walking";
        }
        public override void UpdateState()
        {
            base.UpdateState();
            _person.Satiation--;
            _person.Happiness--;

            if (_person.Position.Distance(_person.Destination) < 1)
            {
                Random random = new Random();
                Vector2D randDest = new Vector2D((float) random.NextDouble() * 100f, (float) random.NextDouble() * 100f);
                Vector2D newPos = _person.Position.UnitTowards(randDest,5f);
                _person.MoveTo(newPos);
            }

            if (_person.Satiation < 30)
            {
                _sc.ChangeState(_sc.hungryState);
            }
            if (_person.Happiness < 80)
            {
                _sc.ChangeState(_sc.sadState);
            }
        }
    }

    public class GameItem : IDisposable
    {
        public string _name;
        public int _uses;
        public float _satiation;
        public float _happiness;
        public Person _person;

        public virtual void Use()
        {
            _person.Happiness += _happiness;
            _person.Satiation += _satiation;
            _uses -= 1;

            if (_uses <= 0)
                this.Dispose();
        }

        public virtual object Clone(Person person)
        {
            GameItem clone = (GameItem)MemberwiseClone();
            clone._person = person;
            return clone;
        }

        public void Dispose() { }

        public virtual void OnCreate() { }

        public GameItem()
        {
            OnCreate();
        }

        public GameItem(Person person)
        {
            _person = person;
            OnCreate();
        }

    }

    public class Burger : GameItem
    {
        public override void OnCreate()
        {
            base.OnCreate();
            _name = "Burger";
            _uses = 5;
            _satiation = 20f;
            _happiness = 10f;

        }
        public Burger(Person person) : base(person) { }
        public Burger() : base() { }
    }

    public class FidgetSpinner : GameItem
    {
        public override void OnCreate()
        {
            base.OnCreate();
            _name = "Fidget Spinner";
            _uses = 10;
            _satiation = 0f;
            _happiness = 10f;

        }
        public FidgetSpinner(Person person) : base(person) { }
        public FidgetSpinner() : base() { }
    }

}
